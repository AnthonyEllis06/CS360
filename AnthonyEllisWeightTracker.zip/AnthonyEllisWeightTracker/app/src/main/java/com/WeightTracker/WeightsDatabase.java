package com.WeightTracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class WeightsDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME ="WeightsDatabase";
    private static final int VERSION = 1;

    public WeightsDatabase(Context context){
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class WeightsTable {
        private static final String TABLE = "Weights";
        private static final String COL_ID = "_id";
        private static final String COL_DATE ="Date";
        private static final String COL_WEIGHT ="Weight";
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL("create table "+ WeightsTable.TABLE + " (" +
                WeightsTable.COL_ID + " integer primary key autoincrement, " +
                WeightsTable.COL_DATE + " text, " +
                WeightsTable.COL_WEIGHT + " double)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL("drop table if exists "+ WeightsTable.TABLE);
        onCreate(db);
    }

    public long addWeight(String date, String weight){
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(WeightsTable.COL_DATE, date);
        values.put(WeightsTable.COL_WEIGHT, weight);
        long weightID = db.insert(WeightsTable.TABLE, null, values);
        return weightID;
    }
    public ArrayList<Weight> getWeights(){
        SQLiteDatabase db = getReadableDatabase();
        ArrayList<Weight> weights = new ArrayList<Weight>();
        String sql = "select * from " + WeightsTable.TABLE;
        Cursor cursor = db.rawQuery(sql,new String[] {});
        if(cursor.moveToFirst()){
            do{
                long id = cursor.getLong(0);
                String dateVal = cursor.getString(1);
                double weightVal = cursor.getDouble(2);
                weights.add(new Weight(id,dateVal,weightVal));
            }while(cursor.moveToNext());
            cursor.close();
        }
        return weights;
    }
    public Weight getWeight(String date, String weight){
        SQLiteDatabase db = getReadableDatabase();
        String sql = "select * from " + WeightsTable.TABLE + " where " +
                WeightsTable.COL_DATE + " = ? and " +
                WeightsTable.COL_WEIGHT + " = ? LIMIT 1";
        Cursor cursor = db.rawQuery(sql,new String[] {date,weight});
        if(cursor.moveToFirst()){
            long id = cursor.getLong(0);
            String dateVal = cursor.getString(1);
            double weightVal = cursor.getDouble(2);
            cursor.close();
            return new Weight(id,dateVal,weightVal);
        }
        else
            return null;
    }

    public boolean updateWeight(long id, String dateVal, double weightVal){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        if(dateVal != null)
            values.put(WeightsTable.COL_DATE,dateVal);
        if(weightVal != 0.0)
            values.put(WeightsTable.COL_WEIGHT,weightVal);

        int rowsUpdated = db.update(WeightsTable.TABLE,values, "_id = ?",
                new String[] {Float.toHexString(id)});
        return rowsUpdated> 0;

    }

    public boolean DeleteWeight(long id) {
        SQLiteDatabase db = getWritableDatabase();
        int rowsDeleted = db.delete(WeightsTable.TABLE, WeightsTable.COL_ID + " = ?",
                new String[] {Long.toString(id)});
        return rowsDeleted>0;
    }
}
