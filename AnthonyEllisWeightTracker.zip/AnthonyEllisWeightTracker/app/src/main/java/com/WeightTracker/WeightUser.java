package com.WeightTracker;

public class WeightUser {
    private double goal;
    private String UserName;
    private String Password;
    public WeightUser(String user, String pass, double goalWeight){
        this.UserName = user;
        this.Password = pass;
        this.goal = goalWeight;
    }
}
