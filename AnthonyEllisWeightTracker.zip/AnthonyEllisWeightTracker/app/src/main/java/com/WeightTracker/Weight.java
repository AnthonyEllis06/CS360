package com.WeightTracker;

public class Weight {
    private long id;
    private double weightVal;
    private String dateVal;
    public Weight(long newID, String dateV, double weightV){
        this.id = newID;
        this.weightVal = weightV;
        this.dateVal=dateV;
    }
    public long getId() {
        return id;
    }
    public double getWeightVal() {
        return weightVal;
    }

    public void setWeightVal(double weightVal) {
        this.weightVal = weightVal;
    }
    public String getDateVal() {
        return dateVal;
    }

    public void setDateVal(String dateVal) {
        this.dateVal = dateVal;
    }

}
