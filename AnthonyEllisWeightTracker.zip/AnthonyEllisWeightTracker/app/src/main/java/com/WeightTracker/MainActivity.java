package com.WeightTracker;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.ColorInt;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.text.TextWatcher;
import android.widget.Button;
import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {
    private WeightUser user;
    private WeightsDatabase db;

    private Weight selectedWeight;
    private class WeightTextWatcher implements TextWatcher {
        public WeightTextWatcher(){
            super();
        }
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after){
        }
        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count){
            Button add = findViewById(R.id.AddButton);
            Button delete = findViewById(R.id.DeleteButton);
            Button update = findViewById(R.id.UpdateButton);
            add.setEnabled(true);
            update.setEnabled(true);
            delete.setEnabled(false);
        }
        @Override
        public void afterTextChanged(android.text.Editable s){
        }

    }

    //neccesary classes for recycler view.

    private static class WeightHolder extends RecyclerView.ViewHolder{
        private final TextView DateTextView;
        private final TextView WeightTextView;
        private final TextView LostTextView;

        public WeightHolder(LayoutInflater inflater, ViewGroup parent){
            super(inflater.inflate(R.layout.list_item_weight,parent, false));
            DateTextView = itemView.findViewById(R.id.DateSpot);
            WeightTextView = itemView.findViewById(R.id.WeightSpot);
            LostTextView = itemView.findViewById(R.id.LostSpot);

        }
    }
    private class WeightAdapter extends RecyclerView.Adapter<WeightHolder>{
        private ArrayList<Weight> WeightList;
        private Context context;

        public WeightAdapter(ArrayList<Weight> weightList, Context context){
            this.WeightList = weightList;
            this.context = context;
            setHasStableIds(true);
        }

        @NonNull
        @Override
        public WeightHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType){
            LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
            return new WeightHolder(layoutInflater,parent);
        }

        @Override
        public void onBindViewHolder(@NonNull WeightHolder holder, int position){
            Weight currWeight = WeightList.get(position);
            holder.DateTextView.setText(currWeight.getDateVal());
            holder.WeightTextView.setText(String.format("%.1f lbs",currWeight.getWeightVal()));
            double prevWeight;
            double lossWeight;
            int colorNum;
            if(position == 0) {
                lossWeight = 0.0;
                prevWeight = currWeight.getWeightVal();
            }
            else {

                lossWeight = WeightList.get(position - 1).getWeightVal()-currWeight.getWeightVal();
                if(lossWeight > 0){
                    colorNum = ContextCompat.getColor(context,R.color.orange);
                }
                else{
                    colorNum = ContextCompat.getColor(context,R.color.purple);
                }
                holder.LostTextView.setTextColor(colorNum);
                prevWeight = WeightList.get(position-1).getWeightVal();
            }
            holder.LostTextView.setText(String.format("%.1f lbs",(prevWeight-currWeight.getWeightVal())));
        }

        @Override
        public int getItemCount(){
            return WeightList.size();
        }

        @Override
        public long getItemId(int position){
            if(WeightList == null || position < 0 || position >= WeightList.size()){
                return RecyclerView.NO_ID;
            }
            else{
                return WeightList.get(position).getId();
            }
        }

        public void setWeightList(ArrayList<Weight> newWeightList){
            this.WeightList.clear();
            this.WeightList.addAll(newWeightList);
            notifyDataSetChanged();
        }

    }
    private  ArrayList<Weight> weights;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        //setting edge to edge
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // database and adapter
        db = new WeightsDatabase(this);
        weights = db.getWeights();

        //setting up variables
        EditText dateField = findViewById(R.id.EditDate);
        EditText weightField = findViewById(R.id.EditWeight);
        RecyclerView weightDateView = findViewById(R.id.WeightDateView);
        Button addButton = findViewById(R.id.AddButton);
        Button deleteButton = findViewById(R.id.DeleteButton);
        Button updateButton = findViewById(R.id.UpdateButton);



        WeightAdapter adapter = new WeightAdapter(weights,this);
        weightDateView.setAdapter(adapter);
        weightDateView.setLayoutManager(new LinearLayoutManager(this));

        //adding listeners
        final GestureDetector gestureDetector = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onSingleTapUp(MotionEvent e){
            return true;
            }
            @Override
            public void onLongPress(MotionEvent e){
                super.onLongPress(e);
                View child = weightDateView.findChildViewUnder(e.getX(),e.getY());
                if(child != null){
                    int position = weightDateView.getChildAdapterPosition(child);
                    if(position != RecyclerView.NO_POSITION){
                        Weight longClickedWeight = weights.get(position);
                    }
                }
            }
        });
        weightDateView.addOnItemTouchListener(new RecyclerView.OnItemTouchListener() {
            @Override
            public boolean onInterceptTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {
                View child = rv.findChildViewUnder(e.getX(), e.getY());
                if (child != null && gestureDetector.onTouchEvent(e)) {
                    int position = rv.getChildAdapterPosition(child);
                    if (position != RecyclerView.NO_POSITION) {
                        Weight clickedWeight = weights.get(position);
                        OnWeightSelected(clickedWeight);
                        updateButton.setEnabled(false);
                        addButton.setEnabled(false);
                        deleteButton.setEnabled(true);
                        return true;
                    }
                }
                return false;
            }
            @Override
            public void onTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {
            }
            @Override
            public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {
            }
        });
        weightField.addTextChangedListener(new WeightTextWatcher());
        addButton.setOnClickListener(v -> {
            addWeight();
            adapter.setWeightList(db.getWeights());
            adapter.notifyDataSetChanged();
        });
        deleteButton.setOnClickListener(v -> {
            deleteWeight();
            adapter.setWeightList(db.getWeights());
            adapter.notifyDataSetChanged();
        });
        updateButton.setOnClickListener(v -> {
            updateWeight();
            adapter.setWeightList(db.getWeights());
            adapter.notifyDataSetChanged();
        });


    }
    @Override
    protected void onStart(){
        super.onStart();
    }
    @Override
    protected void onStop(){
        super.onStop();
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
    }
    @Override
    protected void onPause(){
        super.onPause();
    }
    @Override
    protected void onResume(){
        super.onResume();
    }
    //Button Change Listener Methods
    private void addWeight(){
        String date = ((EditText)findViewById(R.id.EditDate)).getText().toString();
        String weight = ((EditText)findViewById(R.id.EditWeight)).getText().toString();
        db.addWeight(date,weight);
    }
    private void deleteWeight(){
        String date = ((EditText)findViewById(R.id.EditDate)).getText().toString();
        String weight = ((EditText)findViewById(R.id.EditWeight)).getText().toString();
        db.DeleteWeight(db.getWeight(date,weight).getId());
    }
    //FIXLATER after Recycler View functionality is done
    private void updateWeight(){
        String date = ((EditText)findViewById(R.id.EditDate)).getText().toString();
        String weight = ((EditText)findViewById(R.id.EditWeight)).getText().toString();
        selectedWeight.setDateVal(date);
        selectedWeight.setWeightVal(Double.parseDouble(weight));
        db.updateWeight(selectedWeight.getId(),date, Double.parseDouble(weight));
    }
    //Recycler View Listener Methods
    private void OnWeightSelected(Weight weight) {
        ((EditText)findViewById(R.id.EditDate)).setText(weight.getDateVal());
        ((EditText)findViewById(R.id.EditWeight)).setText(String.format("%.1f",weight.getWeightVal()));
        this.selectedWeight = weight;
    }


    //Text change listener class

}